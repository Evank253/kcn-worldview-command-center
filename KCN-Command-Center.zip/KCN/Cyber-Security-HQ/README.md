# KCN Cyber Security Headquarters

**Status**: Scaffolding  
**Type**: Independent system

## Purpose
Dedicated cybersecurity command platform.  
Can run as its own globe or feed selected events into Worldview.

## Core Features (planned)
- Independent cyber-focused globe
- Live event / packet list in Wireshark style
- Systems health monitoring dashboard
- Attack tracking and timeline
- Anomaly / “out of the ordinary” detection
- Incident severity, affected assets, and response tooling
- Export / share selected events to Worldview

## Tech Direction
- Frontend: React / Next.js + MapLibre or Cesium
- Live feeds: Simulated + real public cyber threat intelligence sources
- Packet-style list: Custom high-performance table component

## Owner Access
Fully free and unrestricted.
