# KCN Human AI Personal Growth & Development

**Status**: Scaffolding  
**Type**: Independent system

## Purpose
Self-discovery and personal development platform powered by a privacy-first AI companion.

## Core Features (planned)
- Personal Discovery Profile
  - Interests, strengths, learning style, motivations
- AI Career & Skills Map
  - Built from conversation patterns and activities rather than forced job questions
- AI Resume + Skills-Based Portfolio builder
- Proof-of-Skill system (living evidence of projects, challenges, contributions)
- Human + AI partnership for reflection and growth
- Full user control over memory, profile contents, and sharing
- Never judges worth or makes limiting labels

## Tech Direction
- Frontend: React / Next.js
- Conversation & memory: Privacy-respecting local or controlled storage
- Profile & portfolio: Structured user-owned data model
- Export: Resume, portfolio site, skills map

## Owner Access
Fully free and unrestricted.
